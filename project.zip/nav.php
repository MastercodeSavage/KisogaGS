    <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
<!--    <meta http-equiv="refresh" content="2">-->
  <title>kisoga general stores ltd</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet"> 
  <link href="css/dash.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
  <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
  <style type="text/css">
   .container { margin:150px auto;}

  </style>
</head>

<body class="bg" style="background-color:#dbcdb9;">
    <!-- Modal -->
<div class="modal  modal-fluid fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="false" >
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header danger-color-dark">
        <h5 class="modal-title text-center" id="exampleModalLabel">CURRENT DEBTS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="background-color:#dbcdb9;">
 <div class="container-fluid">
				<h4 class="text-center text-elegant h3">SELECT THE SALESMAN</h4>
				<nav class="nav  nav-tab  justify-content-center">
					<a href="#saledebts" class="nav-item text-light btn-outline-elegant btn-sm btn nav-link " data-toggle="tab">SALES</a>
					<a  href="#emptydebts"  class="nav-item text-light btn-outline-elegant btn btn-sm nav-link" data-toggle="tab">EMPTIES</a>	
				</nav>
				<div class="tab-content">
					<div class="container-fluid tab-pane " id="saledebts">
						<div class="form-group ">
							<div class="input-group input-group-sm">
								<select id="cli" class=" form-control form-control-sm"  >
									<option value="NULL" >SALESMAN</option>
									<?php include "marketeer.php"; ?>
								</select>
							</div>
						</div>
						<div class="container-fluid">
							<table class="table table-border">
								<thead>
									<tr>
										<th>Mills</th>
										<th>Brand</th>
										<th>Order</th>
										<th>Total(shs)</th>
									</tr>
									<tbody id="viewx">
										
									</tbody>
								</thead>
							</table>
						</div>
					</div>
					<div class="  container-fluid tab-pane " id="emptydebts">
						<!-- <h4 class="text-center text-elegant h3">EMPTIES</h4> -->
						<div class="form-group ">
							<div class="input-group input-group-sm">
								<select id="empcli" class=" form-control form-control-sm" >
									<option value="NULL" >SALESMAN</option>
									<?php include "marketeer.php"; ?>
								</select>
							</div>
						</div>
						<div class="container-fluid " id="empretrieve"></div>
						
					</div>
				</div>
			</div>
			
		<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/popper.min.js"></script>
		<script type="text/javascript" src="js/mdb.min.js"></script>
			<script type="text/javascript">
				$(document).ready(function(){
					$("#cli").change(function(){
						var txt = $("#cli").val();
						$.post("fetchsalesdebts.php",{cli:txt},function(result){
							$("#viewx").html(result);
							});
						});
					});
				$(document).ready(function(){
					$("#empcli").change(function(){
						var txt = $("#empcli").val();
						$.post("emptydebt.php",{value:txt},function(result){
							$("#empretrieve").html(result);
							});
						});
					});
                $(function(){
          
            $("#desk").click(function(){
              pressed = 1;
              if(pressed == 1 ){
                $("#iterate").load("updateDb.php");
                $("#desk").hide();
              }
            });

                pressed = 0;
                if(pressed == 0){
                   $("#desk").show();
                 }
          });
		
			</script>

      </div>
      <div class="modal-footer danger-color-dark">
        <button type="button" class="btn btn-elegant btn-sm" data-dismiss="modal">close</button>
    
      </div>
    </div>
  </div>


    </div>
    <!-- the logout modal -->
    <!-- Side Modal Top Right -->

<!-- To change the direction of the modal animation change .right class -->
<div class="modal fade left" id="logout" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

    <!-- Add class .modal-side and then add class .modal-top-right (or other classes from list above) to set a position to the modal -->
    <div class="modal-dialog modal-side modal-bottom-left" role="document">


      <div class="modal-content">
        <div class="modal-header danger-color-dark">
          <h4 class="modal-title w-100 h4 h4-responsive text-white"  id="myModalLabel"><i class="fas fa-save mr-3"></i>save today's stock?</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <i id="results"></i>
        </div>
        <div class="modal-body">
          <div class="ml-5 pl-5">
          <a href="" class="btn btn-info btn-sm logoutbtn" id="yes">yes</a>
         <a href="#" class="btn btn-danger btn-sm logoutbtn" id="no">no</a>
        
        
        </div>
        </div>
        <!-- div class="modal-footer">
          <button type="button" class="btn btn-elegant" data-dismiss="modal">cancel</button>
           <button type="button" class="btn btn-primary">Save changes</button>
        </div>  -->
      </div>
    </div>
  </div>
  <!-- Side Modal Top Right -->
    <!-- /the logout modal -->
  <!--    the stock modal-->
  <!-- Full Height Modal Right -->
<div class="modal fade top" id="fullHeightModalRight" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="true" >

    <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
    <div class="modal-dialog modal-full-height modal-top" role="document">


      <div class="modal-content">
        <div class="modal-header danger-color-dark text-center ">
          <h4 class="modal-title w-100 text-elegant " id="myModalLabel">TODAY IN STOCK</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body " style="background-color:#dbcdb9;">
            <!-- <table> -->
  <!-- <h4 class="text-center" >OPENING STOCK</h4> -->

  <table class="table table-border table-condensed table-hover table-striped">
  <thead>
  <tr class="">
    <th><b>Milligarms</b></th>
    <th><b>Brand</b></th>
    <th><b>stock total</b></th>
    <th><b>stock amount(shs)</b></th>
    <th><b>Date</b></th>
  </tr>
  </thead>
<?php
include "connection.inc.php";
$date1=date('Y-m-d');
$query = mysqli_query($conn,"SELECT * FROM stock_track  WHERE date='$date1' ");
while($row = mysqli_fetch_array($query)){
  $bottle = $row['bottle'];
  $date = $row['date'];
  $stock_amount = $row['stockamount'];
  $stock_total = $row['stocktotal'];

  $sq ="SELECT * FROM filledbottles WHERE id = '$bottle'";
  $query2 = mysqli_query($conn,$sq);
  while($rw = mysqli_fetch_array($query2)){
  	$identify = $rw['id'];
  	$brandid = $rw['brandid'];
  	$qtyId = $rw['quantites'];
  $s="SELECT mills FROM quantites WHERE quantityid = '$qtyId' ";
  $rs = mysqli_query($conn,$s);
  while($r=mysqli_fetch_array($rs)){
  	$qty=$r['mills'];
  }
  $qb = "SELECT brandname FROM brand WHERE brandid = '$brandid'";
  $q = mysqli_query($conn,$qb);
  while($w = mysqli_fetch_array($q)){
  	$brandname = $w['brandname'];
  }

}?>
<tr class="table-condesenced">
<td>  <? echo $qty;?></td>
<td> <? echo $brandname;?></td>
<td><? echo $stock_amount; ?></td>
<td><? echo $stock_total; ?></td>
<td><? echo $date; ?></td>
</tr>
<?


}
?>
</table>
<!-- </table> -->

        </div>
        <div class="modal-footer  danger-color-dark">
          <button type="button" class="btn btn-sm btn-elegant" data-dismiss="modal">Close</button>
          
        </div>
      </div>
    </div>

  </div>
<div class="modal  modal-fluid fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="true" >
  <div class="modal-dialog modal-sm" role="document">
  
      <div class="modal-body container" style="background-color:#dbcdb9;">
       <!-- <div class=""> -->
          <h4 class="h4 h4-responsive text-center text-info">
          <b> Record changed successfully</b>
          </h4>    
          <!-- </div> -->
          </div>

    
      </div>
    </div>
<!--
<div class="modal fade bottom" id="edit1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="true" >
  <div class="modal-dialog modal-sm" role="document">
  
      <div class="modal-body container">
       <div class="card cards-bg">
           		<a href="changerecord.php?change=67" class="text-light btn-outline-danger btn-sm btn"> edit client order</a>
                    <a href="changerecord.php">change record</a>
					<a  href="Edit.php?edit=39"  class="nav-item btn text-light btn-outline-danger  btn-sm "> edit ccba</a>	
         
          </div>
          </div>

    
      </div>
    </div>
-->
  
<div class="modal fade bottom" id="edit1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="true" >

    <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
    <div class="modal-dialog  modal-bottom" role="document">


      <div class="modal-content">
        <div class="modal-header danger-color-dark text-center ">
          <h4 class="modal-title w-100 text-white mx-auto" id="myModalLabel"><i class="fas fa-exclamation-circle mr-2"></i>You are changing sensitive information </h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" style="background-color:#dbcdb9;">
            <div class="container-fluid ml-5">
          	<a href="editclient.php" class="text-light btn-outline-danger btn-sm btn"> edit client order</a>
<!--                    <a href="changerecord.php">change record</a>-->
					<a  href="editccba.php"  class="nav-item btn text-light btn-outline-danger  btn-sm "> edit ccba</a>	
         </div>
        </div>
        <div class="modal-footer  danger-color-dark">
          <button type="button" class="btn btn-sm btn-elegant" data-dismiss="modal">Close</button>
          
        </div>
      </div>
    </div>

  </div>

    

<div class="container-fluid mb-5">
<nav class="  navbar navbar-dark danger-color-dark fixed-top ">
<a class="navbar-brand">
    
    
<div>

    
                <!--this arrow is supposed to rotate-->
    <h3 class="fas fa-ellipsis-h" id="sidebarCollapse" ></h3>
    <!-- <h1 class="btn btn-elegant btn-sm" id="desk">SAVE STOCK</h1> -->
     <!-- <h1 class="btn btn-elegant btn-sm" data-toggle="modal" data-target="#logout" >SAV</h1> -->
<!--    <button class=" btn btn-elegant disabled" id="sidebarCollapse">sidebar</button>-->
    
    
<!--                <img id="sidebarCollapse"  class="img-responsive rot-right  " width=50% src="img/arrow.png">-->

<!--                <span></span>-->
            </div>
</a>

<h3 class="text-center text-white" >KISOGA GENERAL STORES LIMITED</h3>


<div class="mx-0" >
<!--  <button class="btn btn-elegant btn-sm " onclick="setTimeout(alert3(),3000)" ><a>alert pop </a></button> -->
    
    <!-- <button class="btn btn-elegant btn-sm" type="button"  data-toggle="modal" data-target="#edit">edit</button> -->
    <button class="btn btn-elegant btn-sm" type="button"  data-toggle="modal" data-target="#basicExampleModal">debts</button>
   <button class="btn btn-elegant btn-sm" type="button"  data-toggle="modal" data-target="#fullHeightModalRight">stock</button>
       <!--  <input class="btn btn-elegant btn-sm" type="button" value = "Test the alert" onclick="alert('Alert this pages');" /> -->

<!-- <a href="logout.php" class="d-inline btn btn-elegant btn-sm">logout</a></div>-->
<!--     <a href="#" class="d-inline btn btn-elegant btn-sm">stock</a>-->
    </div>

</nav>
    </div>

<script type="text/javascript">
  $(document).ready(function(){
    $(".logoutbtn").click(function(){
      val= $(this).attr("id");

      $.post("newlogout.php",{value:val},function(result){
        $("#results").html(result);
      });
    });
  });
</script>
    
    
    
    <!--    the records saved alert-->
<!--
    <div class="alert alert-warning alert-dismissible fade show mt-5" role="alert">
  <strong>Holy guacamole!</strong> You should check in on some of those fields below.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
-->


<!--creating a side nav-->

