<?php
include "connection.inc.php";
$sq = "SELECT * FROM ccbadelivery ORDER BY date";
static $var =0;
$query = mysqli_query($conn,$sq);
while($row=mysqli_fetch_array($query)){
	$bottle = $row['bottle'];
	$date = $row['date'];
	$total =$row['total'];
	$delivery = $row['ccbdelivery'];
	$var++;
	
$sql ="SELECT * FROM filledbottles WHERE id = '$bottle'";
$query2 = mysqli_query($conn,$sql);
while($rw = mysqli_fetch_array($query2)){
	$brandid = $rw['brandid'];
	$qtyId = $rw['quantites'];
$s="SELECT mills FROM quantites WHERE quantityid = '$qtyId' ";
$rs = mysqli_query($conn,$s);
while($r=mysqli_fetch_array($rs)){
	$qty=$r['mills'];
}
$qb = "SELECT brandname FROM brand WHERE brandid = '$brandid'";
$q = mysqli_query($conn,$qb);
while($w = mysqli_fetch_array($q)){
	$brandname = $w['brandname'];
}

}

?>
<tr scope="row" class="table table-borderd border border-info">
	<td><? echo $date; ?></td>
	<td><? echo $qty; ?></td>
	<td><? echo $brandname; ?></td>
	<td><? echo $delivery; ?></td>
	<td><? echo $total;?></td>
	<td><a href="Edit.php?edit=<? echo $date;?>" class=" btn btn-sm btn-secondary btn-elegant">Edit</a></td>
	<td><a href="delete.php?rec=<? echo $date; ?>" class="btn btn-sm btn-danger ">Delete</a></td>
</tr>
<br>
<?php
}

?>
<script>
	$(document).ready(function(){
		$("#history").click(function(){
			$("#t1").toggle();});
		});
</script>