<?php
include "connection.inc.php";
if(isset($_POST['qty'])){
	$val = $_POST['qty'];
	
	$sql = "SELECT * FROM emptyprice WHERE quantities = '$val'";
	$query2 = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_array($query2)){
		$shellprice = $row['shellprice'];

		
	}
	echo $shellprice;
}


?>