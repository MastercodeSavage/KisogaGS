<?php
//to be included into the select tag on the empty shell table
include "connection.inc.php";
$mills = "SELECT * FROM quantites ";
$query = mysqli_query($conn,$mills);
while($result = mysqli_fetch_array($query)){
	$quantityid = $result['quantityid'];
	$mills = $result['mills'];
	
?>
	<option value="<?php echo $quantityid;?>"><?php echo $mills ;?></option>	
<?php	
	}
?>