<?php
/*
login scripts for the user
database dependent database must contain
user table with username , user_email and password
*/
session_start();
if(isset($_POST['login'])){
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$sql = "SELECT username FROM user WHERE user_email = '$email' AND password = '$password'";
	$query = mysqli_query($conn,$sql);
	
	if(mysqli_num_rows($query) > 0){
		$row = mysqli_fetch_array($query);
		$username = $row['username'];
		$_SESSION['USER']['ADMIN'] = $username;
		
		echo "<script>window.open('dashboard.php','_self');</script>";
		
		}
		else{
?>
		<div class="alert alert-danger ">
			Email or password incorect
			<button type="button" data-dismiss="alert" class="close"  aria-label="Close">
		 <span aria-hidden="true">&times;</span>
			</button>
		</div>
<?php
		}

}


?>