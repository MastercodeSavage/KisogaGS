<?php
class record{
	public $date,$brand,$price,$quantiy,$customer,$total,$order;
	public function __construct($d,$b,$ml,$up,$client,$o,$tot){
		$this->date = $d;
		$this->brand = $b;
		$this->quantiy = $ml;
		$this->price  = $up;
		$this->customer = $client;
		$this->order = $o;
		$this->total = $tot;
		echo "<script> alert('saved successfully'); </script>";
	}
}
?>