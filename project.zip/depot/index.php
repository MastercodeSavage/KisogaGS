<!DOCTYPE html>
	<html>
		<head>
			<title>trialform3</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/mdb.min.css" rel="stylesheet">
		<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
		<script type="text/javascript" src="js/popper.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/mdb.min.js"></script>
			
		</head>
		<body>
			<div class="container-fluid">
				<div class="accent-1 card card-elegant" >
					<div class="accent-1 card-header bg-dark">
						<h4 class="accent-1 h4 text-secondary text-center">CCBA</h4>
					</div>
					<div class="accent-1 card-body">
						<form class="container"  method="post" name="ccbaDelivery">
							<div class="form-row">
							 <div class="col-2">
								<label class="badge badge-dark  hover text-center ">quantiy</label>
								<div class=" input-group input-group-sm">
									<select class="form-control form-control-sm" name="quantity" id="select1">
										<option value="null">select mils</option>
										<?php include "quantity.inc.php";?>
									</select>
								</div>
							 </div>
								<div class="col-2 fixed">
									<label class="badge badge-dark  hover text-center ">Brand</label>
									<div class=" input-group input-group-sm">
									<select  class="form-control form-control-sm" name="brand" id="brand">
										<option value="null">select Brand</option>
									</select>
								</div>
								</div>
								<div class="col-2">
									<label class="badge badge-dark  hover text-center ">price</label>
									<div class="input-group input-group-sm">
										<div class="accent-1 form-control form-control-sm pt-1 pb-2" id="unitprice"></div>	
									</div>
								</div>
								<div class="col-2">
									<label class="badge badge-dark text-center ">Delivery</label>
									<div class="input-group input-group-sm">
										<input required type="number" class="border rounded pt-0" name="deliveries" id="deliveries">			
									</div>
								</div>
								<div class="col-2">
									<label class="badge badge-dark text-center ">Total(shs)</label>
									<div class="input-group input-group-sm">		
								<div class="accent-1 form-control form-control-sm pt-1 pb-2" id="tot"></div>
									</div>
								</div>
							</div>
							<div class="form-row">
								<div class="form-group col-md-4 col-md-offset-4">
								    <div class="accent-1 input-group input-group-sm">
										<button type="submit" name="record" class="btn btn-secondary btn-sm btn-elegant">Record</button>
									</div>
								</div>
							</div>	
						</form>
						<?php include "submit.php";?>
					</div>
					<div class="card card-lg">
						<div class="card-header">
						<button id="records" class="btn btn-primary btn-lg">RECORDS</button>
						</div>
						<div class="accent-1 card-body">
							<table class="table table-hover table-condensed table-striped table-active">
								<thead>
									
										<th>Time</th>
										<th>Milligrams</th>
										<th>Brand</th>
										<th>Stock</th>
										<th>Total</th>
								
								</thead>
								<tbody id="freshrecords"></tbody>
							</table>
						</div>
					</div>
					
				</div>
			</div>
			<script type="text/javascript">
				$(document).ready(function(){
			$("#select1").change(function(){
			var mls = $("#select1").val();
			$.post("brand.php",{value:mls},function(results){
				$("#brand").html(results);
				});
			});
		});
		$(document).ready(function(){
		$("#brand").change(function(){
			var mls = $("#brand").val();
			var milz=$("#select1").val();
			$.post("price.php",{brand:mls,qty:milz},function(resu){
				$("#unitprice").html(resu);
				});
			});
		});
		$(document).ready(function(){
		$("#deliveries").keyup(function(){
			var order = $("#deliveries").val();
			var qty =$("#select1").val();
			var bra = $("#brand").val();
			$.post("total.php",{orderz:order,quantity:qty,brand:bra },function(result){
				$("#tot").html(result);
				});
			});
		});
		$(document).ready(function(){
			$("#records").click(function(){
				$("#freshrecords").load("retrieve.php",function(responseTxt,statusTxt,xhr){
					if(statusTxt == "success"){
						continue;
					}
					if(statusTxt != "success"){
						alert("ERROR:"+xhr.status() );
					}
					});
				});
			});
			</script>
		</body>
	</html>