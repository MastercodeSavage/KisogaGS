<?php
//brand option snipet
$conn = mysql_connect("localhost","root","","dailystockkeep");
$query = "SELECT * FROM brand";
$result = mysqli_query($conn,$query);
while($data=mysqli_fetch_array($result)){
	$id = $row['brandid'];
	$brandname['brandname'];
?>
	<option value="<?php echo $id;?>"><?php echo $brandname;?></option>
<?php 	
}
//included in table form
mysqli_close($conn);
?>