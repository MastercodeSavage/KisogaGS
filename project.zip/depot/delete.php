<?php
include "connection.inc.php";
$date = $_GET['rec'];
$var=mysqli_query($conn,"DELETE FROM ccbadelivery WHERE date='$date'");

?>
<script>
	window.open("index.php#records","_self");
</script>