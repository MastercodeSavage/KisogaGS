<?php
//connection variables alter on serverchange
$servername = "localhost";
$username = "root";
$password ="";
$database ="dailystockkeep";
//connection variable to call on every database  connection
$conn = mysqli_connect($servername,$username,$password,$database);
//if($conn){
//	echo "success";
//}
//else{
	//echo "failure";
//}
?>