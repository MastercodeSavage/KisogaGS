<?php
include "connection.inc.php";
if(isset($_POST['orderz'])){
$order = $_POST['orderz'];
if(!empty($order)){
	$quantity =  $_POST['quantity'];
	$brand = $_POST['brand'];
	$sql = "SELECT * FROM filledbottles WHERE quantites = '$quantity' AND brandid ='$brand'";
	$query = mysqli_query($conn,$sql);
	//if($query){
		//echo "<script>alert('success')</script>";
	//}
while($row = mysqli_fetch_array($query)){
	$pricevalue = $row['pricevalue'];
	
}
if($quantity != null ){
	$tot = $pricevalue * $order;
echo $tot;}
}

	
}

?>