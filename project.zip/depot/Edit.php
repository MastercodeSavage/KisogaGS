<head>
	<title>EDIT RECORD</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel= "stylesheet" href = "css/mdb.min.css" >
	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/mdb.min.js"></script>
		
</head>
<?php
include "connection.inc.php";
$rec = $_GET['edit'];
$var =mysqli_query($conn,"SELECT total ,ccbdelivery FROM ccbadelivery WHERE date ='$rec'");

while($row = mysqli_fetch_array($var)){
	$total = $row['total'];
	$stock = $row['ccbdelivery'];
?>
<body class="accent-1 mdb-skin">
	<div class="container row">
		<div class="card">
			<div class="card-header">Edit Record</div>
		</div>
		<div class="accent-1 card-body">
			<form method="post" class="container">
				<div class=" form-group ">
					<label>Date</label>
					<input readonly="readonly" type="text" class="form-control form-control-sm" value="<? echo $rec;?>">
				</div>
				<div class="form-group  ">
					<label>milligrams</label>
					<select id="select1" name="milligrams" class="form-control ">
					<option value="NULL">select mills</option>
					<? include "quantity.inc.php"; ?>
					</select>
				</div>
				<div class="card-header form-group">
					<label>Brand</label>
					<div class="input-group input-group-lg">
						<select name="brand" id="brand" class="form-control">
						<option value="null">select Brand</option>
					</select>
					</div>
					
				</div>
				<div class="form-group card-header">
					<label class="accent-1 form-text lead text-md">Unit Price</label>
					<span id="unitprice" class="input-group input-group-lg"></span>
				</div>
			</form>
		</div>
	</div>
	<script type="text/javascript">
			$(document).ready(function(){
			$("#select1").change(function(){
			var mls = $("#select1").val();
			$.post("brand.php",{value:mls},function(results){
				$("#brand").html(results);
				});
			});
			});
			$(document).ready(function(){
		$("#brand").change(function(){
			var mls = $("#brand").val();
			var milz=$("#select1").val();
			$.post("price.php",{brand:mls,qty:milz},function(resu){
				$("#unitprice").html(resu);
				});
			});
		});
	</script>
	
</body>
<?php	
}
?>