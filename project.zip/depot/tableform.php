<!DOCTYPE HTMl>
<html>
	<head>
		<title> tableforms </title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/mdb.min.css" rel="stylesheet">
		<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
		<script type="text/javascript" src="js/popper.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/mdb.min.js"></script>
	</head>
	<body class="accent-1 mdb-skin monospace">
		<div class="container-fluid row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<h4 class="h4 text-center text-secondary">CLIENT ORDER FORM</h4>
					</div>
					<div class="card-body">
						<form name="clientform" class="accent-1 form-row align-items-center" method="POST">
							<div class="accent-1 col-2  mr-2 pl-1 pt-2 pb-2 pr-1">
								<div class="input-group input-group-sm">
									<span class="input-group-addon">(mls)</span>
									<select id="select1" class="form-control form-control-sm" name="quantity">
									<option value= "null" class="" selected>select liters</option>
									<?php include "quantity.inc.php";?>
									</select>
								</div>
							</div>
							<div class="accent-1 col-2  mr-1 pl-0 pt-2 pb-2 pr-0">
								<div class="input-group input-group-sm">
									<span class="input-group-addon">Brand</span>
									<select  id="brandlist" class="form-control form-control-sm" name="brand">
									<option value= "null" >select brand</option>
									</select>
								</div>
							</div>
							<div class="accent-1 col-2  mr-1 pl-0 pt-2 pb-2 pr-0">
								<div class="input-group input-group-sm">
									<span class="accent-1 input-group-addon">Unit(shs)</span>
									<div id="price" class="form-control form-control-sm">
									</div>
								</div>
							</div>
							<div class="accent-1 col-2 mr-1 pl-0 pt-2 pb-2 pr-0">
								<div class="accent-1 input-group input-group-sm" >
									<span class="input-group-addon small">Order(qty)</span>
									<input type="number" min="0"  class="accent-1 form-control form-control-sm" name="order" id="order" placeholder="number" required>
								</div>
							</div>
							<div class="accent-1 col-2 mr-1 pl-0 pt-2 pb-2 pr-0">
								<div class="accent-1 input-group input-group-sm">
									<span class="input-group-addon small ">tell</span>
									<input type="tel" class="form-control form-control-sm" placeholder="customer" name="customer" id="customer">
								</div>
							</div>
							<div class="accent-1 col-2 mr-1 pl-0 pt-2 pb-2 pr-0">
								<div class="input-group input-group-sm">
									<span class="input-group-addon ">total</span>
									<span class="form-control form-control-sm" id="total"></span>
								</div>
							</div>
							<div class="accent-1 col-2 mr-2 pl-0 pt-2 pb-2 pr-0">
								<div class="accent-1 input-group input-group-sm ">
									<input type="submit" class=" btn-sm btn-elegant form-control form-control-sm  btn btn-secondary" name="save" value="save" id="submit" >
							    </div>
							</div>
						</form>
					</div>
				</div>
					<div class="col-md-12 mt-4">
						<div class="accent-1 card">
							<div class="accent-1 card-header wrapper">
								<h4 class="h4 text-secondary monospace text-center ">Days Record</h4>
							</div>
							<div class="accent-3 container card-body ">
								<table class="accent-1 table table-condensed">
									<thead>
											<th>mls</th>
											<th>Brand</th>
											<th>price</th>
											<th>total</th>
											<th>order</th>
											<th>customer</th>
									</thead>
									<tbody>
										<span id="row"></span>
									</tbody>
								</table>
							</div>
						</div>
					</div>
			</div>
		</div>
		
		
		<script type="text/javascript">
			$(document).ready(function(){
			$("#select1").change(function(){
			var mls = $("#select1").val();
			$.post("brand.php",{value:mls},function(results){
				$("#brandlist").html(results);
				});
			});
		});
	$(document).ready(function(){
		$("#brandlist").change(function(){
			var mls = $("#brandlist").val();
			var milz=$("#select1").val();
			$.post("price.php",{brand:mls,qty:milz},function(results){
				$("#price").html(results);
				});
			});
		});
	$(document).ready(function(){
		$("#order").keyup(function(){
			var order = $("#order").val();
			var qty =$("#select1").val();
			var bra = $("#brandlist").val();
			$.post("total.php",{orderz:order,quantity:qty,brand:bra },function(result){
				$("#total").html(result);
				});
			});
		});

	</script>
	
	
	</body>
</html>
<?include "submit.php";?>