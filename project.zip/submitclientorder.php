<?php

if(isset($_POST['clientrecord']))
{
	$quantity = $_POST['mils'];
	$brand = $_POST['brand'];
	if(isset($_POST['order'])){
			$order = $_POST['order'];
	}

	$customer =$_POST['customer'];

	if(isset($_POST['debt'])){
		$deb = $_POST['debt'];
	}
	else{
		$deb = 0;
	}

	$d = date("Y-m-d");
	include "connection.inc.php";
	$sql= "SELECT * FROM filledbottles WHERE brandid='$brand' AND quantites='$quantity' ";
	$query = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_array($query)){
		$id = $row['id'];
		$price =$row['pricevalue'];
		$total = $price * $order;
	}

	$insert = "INSERT INTO dailyrecord(count,date,bottle,clientorder,total,client,dept)VALUES('NULL','$d','$id','$order','$total','$customer','$deb')";
	$query2 = mysqli_query($conn,$insert);
	if($query2){
		$qut = mysqli_query($conn,"SELECT * FROM total_stock_table WHERE bottle='$id'");
		while($rw = mysqli_fetch_array($qut)){

			$amount = $rw['stock_amount'];
			$tot = $rw['stock_total'];
			$amount = $amount - $order;
			$tot = $tot - $total;
		
		$qued = mysqli_query($conn,"UPDATE total_stock_table SET  stock_amount='$amount' ,stock_total='$tot' WHERE bottle='$id' ");
		if($qued){
			$sx = mysqli_query($conn,"SELECT * FROM total_stock_table_daily WHERE date='$d' AND bottle='$id'");
		if(mysqli_num_rows($sx)>0){
			$dbq = mysqli_query($conn,"UPDATE total_stock_table_daily SET  amount='$amount',total='$tot' WHERE bottle='$id' AND date='$d'");
		}
		else {

			$dbq = mysqli_query($conn,"INSERT INTO total_stock_table_daily (count,date,amount,total,bottle)VALUES('NULL','$d','$amount','$tot','$id') ");
		}

?>
<script type="text/javascript">

	document.clientorderform.resset();
	window.reload();
</script>
<?
		}
	
	else{
		?>
		<script>
			alert("failed");
		</script>
		<?
	}

}

}
}

?>
