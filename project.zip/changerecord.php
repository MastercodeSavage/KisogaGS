<?php

session_start();
if(!$_SESSION['USER']['ADMIN']) {
    header('Location:index.php');
    ?>
<script type="text/javascript">

window.open("index.php","_self");
</script>
<?
}

 // include"nav.php";

include "nav.php";
if(isset($_GET['change'])){
	$val = $_GET['change'];
		include "connection.inc.php";
		$query = mysqli_query($conn,"SELECT * FROM dailyrecord WHERE count = '$val'");
		while($row = mysqli_fetch_array($query)){
			$bottle =$row['bottle'];
			$order = $row['clientorder'];
			$total = $row['total'];
			$deb = $row['dept'];
			$marketeer = $row['client'];
		$dbc = mysqli_query($conn,"SELECT MarkName FROM marketeer WHERE id = '$marketeer'");
	$extract = mysqli_fetch_array($dbc);
	$Markname = $extract['MarkName'];
		}
$sq ="SELECT * FROM filledbottles WHERE id = '$bottle'";
$query2 = mysqli_query($conn,$sq);
while($rw = mysqli_fetch_array($query2)){
	$brandid = $rw['brandid'];
	$qtyId = $rw['quantites'];
$s="SELECT mills FROM quantites WHERE quantityid = '$qtyId' ";
$rs = mysqli_query($conn,$s);
while($r=mysqli_fetch_array($rs)){
	$qty=$r['mills'];
}
$qb = "SELECT brandname FROM brand WHERE brandid = '$brandid'";
$q = mysqli_query($conn,$qb);
while($w = mysqli_fetch_array($q)){
	$brandname = $w['brandname'];
}

}

		

?>


<!--		<title>kisoga general stores ltd</title>-->
<!--		<link href="css/bootstrap.min.css" rel="stylesheet">-->
<!--		<link href="css/mdb.min.css" rel="stylesheet">-->
		 
     <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <!--<h3>KISOGA GENERAL STORES</h3>-->
            <img  class="img-responsive mx-auto" src="img/kgs.png" width="100%" height="100%">
        </div>

       <div class="container-fluid mt-0">
         <ul class="list-unstyled components">

            <li>
                <a rel="item1" class="fas fa-tachometer-alt" href="dash_home.php"> Dashboard</a>

            </li>
            <li >
                <a  rel="item2"href="client_order.php" class=" mt-2 fa fa-user active"> Client order</a>

            </li>

            <li class="#">
                <a rel="item3"href="ccba.php" class=" mt-2 fa fa-truck"> Ccba delivery</a>
            </li>
            <li>
                <a  rel="item4"href="stock.php" class=" mt-2 fa fa-line-chart"> Stock records</a>

            </li>
            <li>
                <a href="history.php" class=" mt-2 fa fa-archive"> Sales history</a>

            </li>
             <li class="active">
             
             <a class="fas fa-edit" data-toggle="modal" data-target="#edit1" > <span class="caret"></span>edit records</a>
            
             </li>
               <li class="">
               <a href="empty.php" class="fas fa-sync"> empties</a>

             </li>
               <li>
                <a href="#" class=" mt-2 fas fa-sign-out-alt" data-toggle="modal" data-target="#logout"> logout</a>

            </li>


        </ul>
       </div>
     </nav>


<div class="container-fluid  justify-content-center">

    
    <div class="col-auto">
 
        
<form method="post" >
<h4 class=" mt-5 ml-5 pl-5 text-center ">EDIT RECORD</h4>   
<div class="form-group invisible	
    	  col-1" id="disstock">
    	  	
    	  </div>

    <div class="form-row justify-content-center ">
    	 
    	<div class="form-group invisible col-1 ">
      <input type="text"  name="pased" class="form-control form-control-sm" value="<? echo $bottle;  ?>">
          <input type="number"  name="pasedamount" class="form-control form-control-sm" value="<? echo $order;  ?>">
              <input type="number"  name="pasedtotal" class="form-control form-control-sm" value="<? echo $total;  ?>">
    </div>
		<div class="col-auto form-group">
			<div class="input-group input-group-sm">
			<select contenteditable="true" name="milligrams" id="select2" class="form-control form-control-sm">
				<option class="bg-dark" value="<? echo $qtyId;?>"><? echo $qty; ?></option>
				<?php include "quantity.inc.php"; ?>
			</select>
			</div>
		</div>
		<div class="col-auto form-group">
			<div class="input-group input-group-sm">
				<select name="brand" id="brand" class="form-control form-control-sm">
				<option class="bg-dark" value="<? echo $brandid;?>"><? echo $brandname; ?></option>
			</select>
			</div>	
			
		</div>
		<div class="col-auto form-group">
			
			<div class="input-group input-group-sm">
				<input type="number" min="1" value="<? echo $order; ?>" class="form-control form-control-sm" name="order" required id="order">
			</div>
		</div>
		<div class="col-auto form-group">
			<div class="input-group input-group-sm">
			<select name="salesman" class="form-control form-control-sm">
			<option class="bg-dark" value="<? echo $marketeer; ?>"><? echo $Markname; ?></option>
				<? include "marketeer.php" ?>
			</select>
			</div>
		</div>
		<div class="col-auto form-group">
			<button type="submit" class="btn btn-dark btn-sm mt-0" name="editrec" id="button" >CHANGE</button>
			<button class="btn btn-sm btn-danger mt-0" onclick="editclient();">cancel</button>
		</div>
	</div>
    
</form>
        <hr class="hr-light">
    </div>
       <div class="col-auto">   
        
<?php  include "change.php"; ?>
<!--</div>-->
    
 
    <table class="table table-hover table-condensed table-striped ">
    <thead>
    <tr>
             <th>Milligarms</th>
             <th>Brand</th>
             <th>Price(shs)</th>
             <th>Stock</th>
             <th>Total(shs)</th>
             <th>Customer</th>
            <th>Date</th>

           </tr>
    </thead>
    <tbody>
    
    <?php
//include "connection.inc.php";
$query = mysqli_query($conn,"SELECT * FROM dailyrecord ORDER BY count DESC LIMIT 15");
while($row = mysqli_fetch_array($query)){
	$count = $row['count'];
	$date = $row['date'];
	$bottle = $row['bottle'];
	$order = $row['clientorder'];
	$total = $row['total'];
	$client = $row['client'];
	$deb = $row['dept'];
	$dbc = mysqli_query($conn,"SELECT MarkName FROM marketeer WHERE id = '$client'");
	$extract = mysqli_fetch_array($dbc);
	$Markname = $extract['MarkName'];
	
$query2 = mysqli_query($conn,"SELECT * FROM filledbottles WHERE id='$bottle'");
while($dt = mysqli_fetch_array($query2)){
	$brandid = $dt['brandid'];
	$price  =$dt['pricevalue'];
	
	$qty = $dt['quantites'];
	
$q1 = mysqli_query($conn,"SELECT brandname FROM brand WHERE brandid='$brandid'");
$q2 = mysqli_query($conn,"SELECT mills FROM quantites WHERE quantityid='$qty'");
while($d = mysqli_fetch_array($q1)){
	$bname = $d['brandname'];	
}
while($r = mysqli_fetch_array($q2)){
	$v = $r['mills'];
}

}
	
?>
<tr <? if($deb == "1"){
	echo "class='bg-danger' title='not yet cleared'";
	}
     // if ($count==$val){
     //     echo "class='bg-info'";
     // }
    
    
    
    ?> >
	

	<td>
		<? echo $v;?>
	</td>
	<td>
		<? echo $bname; ?>
	</td>
	<td>
		<?echo $price;?>
	</td>
	<td>
		<? echo $order; ?>
	</td>
	<td>
		<? echo $total;?>
	</td>
	<td>
		<? echo $Markname;?>
	</td>
	<td>
		<? echo $date;?>
	</td>
	<td>
<!--		<a class="btn btn-elegant btn-sm"  data-toggle="modal" data-target="#frameModalBottom" >Edit</a>-->
        		<a href="changerecord.php?change=<?php echo $count;?>" class="btn btn-elegant btn-sm" >Edit</a>
        
	</td>
	<?if($deb ==1){?>
	<td>
<!--    the clear debt button was here-->
	</td>
	<? }?>
</tr>

<?	
	
}

?>
    
    </tbody>
    
    
    </table>

</div>
        </div>
    </div>

<script type="text/javascript">
	
	$(document).ready(function(){
			$("#select2").change(function(){
			var mls = $("#select2").val();
			$.post("brand.php",{value:mls},function(results){
				$("#brand").html(results);
				});
			});
		});
</script>

<script type="text/javascript">
	 $(document).ready(function(){
   		$("#brand").change(function(){
   			var mls = $("#brand").val();
   			var milz=$("#select2").val();
   			$.post("getstock.php",{brand:mls,qty:milz},function(resu){
   				$("#disstock").html(resu);
   				});
   			});
   		});
       
$(document).ready(function(){
  $("#order").keyup(function(){
    var qun1 = $("#order").val();
    var qun2 = $("#numavail").val();
    one = parseInt(qun1);
    two = parseInt(qun2);
    if(one > two){

      $("#order").addClass("border-danger");
        // alert("stock not enough");
        alert3();
        var button = $('#button');
    $(button).attr('disabled', 'disabled');

      }
      else{
         var button = $('#button');
        $(button).removeAttr('disabled');
      }
  });
});



</script>
<?

   
}

 include "footer.php";


?>


