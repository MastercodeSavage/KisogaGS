<?php
session_start();
if(!$_SESSION['USER']['ADMIN']) {
    header('Location:index.php');
    ?>
<script type="text/javascript">

window.open("index.php","_self");
</script>
<?
}
?>

<?php include"nav.php";?>


<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <!--<h3>KISOGA GENERAL STORES</h3>-->
            <img  class="img-responsive mx-auto" src="img/kgs.png" width="100%" height="100%">
        </div>

       <div class="container-fluid mt-0">
         <ul class="list-unstyled components">

            <li>
                <a rel="item1" class="fas fa-tachometer-alt" href="dash_home.php"> Dashboard</a>

            </li>
            <li class="active" >
                <a  rel="item2"href="client_order.php" class=" mt-2 fa fa-user active"> Client order</a>

            </li>

            <li>
                <a rel="item3"href="ccba.php" class=" mt-2 fa fa-truck"> Ccba delivery</a>
            </li>
            <li>
                <a  rel="item4"href="stock.php" class=" mt-2 fa fa-line-chart"> Stock records</a>

            </li>
            <li>
                <a href="history.php" class=" mt-2 fa fa-archive"> Sales history</a>

            </li>
             <li class="">
             
             <a class="fas fa-edit" data-toggle="modal" data-target="#edit1" > <span class="caret"></span>edit records</a>
            
             </li>
               <li class="">
               <a href="empty.php" class="fas fa-sync"> empties</a>

             </li>
              <li>
                <a href="#" class=" mt-2 fas fa-sign-out-alt" data-toggle="modal" data-target="#logout"> logout</a>

            </li>

        </ul>
       </div>
     </nav>


<section class="container mt-0">
 <div class="wrapper pull-right">
    <a href="empty.php" class="btn btn-elegant btn-sm mt-5">EMPTIES REQUEST</a>
    </div>
   <!--client_order form -->
   
<div class="container-fluid">
 <h3 class="monospace-text text-center">client order</h3>
    <div class="justify-content-center mx-auto mb-3">
  <span id="showStock"></span>
</div>

<form class="form-inline mx-auto d-flex justify-content-center" method="POST">
     
    <div class="form-group  mx-1">
        
      <select class="form-control form-control-sm" name="mils" id="select1">
    <option value="NULL">select milligrams</option>
									<?php include "quantity.inc.php";?>    
  		</select>
    </div>
    <div class="form-group mx-1">

        <select class="form-control form-control-sm" id="brand" name="brand">
  		<option value="null">select brand</option>
  		</select>
    </div>
    <div class="form-group mx-1" id="price">

    </div>
    <div class="form-group mx-1">

        <input  class="form-control form-control-sm " name="order" required id="order" placeholder="order" 
               type="number" pattern=" 0+\.[0-9]*[1-9][0-9]*$"  onkeypress="return event.charCode >= 48 && event.charCode <= 57"
              min="1"
               >
    </div> 
    <div class="form-group mx-1">

     
       <select name="customer" class="form-control form-control-sm">
  		
    <option value="NULL">Sales Man</option>
							<? include "marketeer.php" ?>
  		</select>
    </div> 
    <!--<div class="form-group mx-1">

        <input type="text"class="form-control form-control-sm "   readonly="readonly" placeholder="total read only">
        
    </div>-->
        
    <div class="checkbox mx-1">
        <label><input type="checkbox" class="form-control form-control-sm " value="1" name="debt"><i class="text-danger">debt</i></label>
    </div>
    <button type="submit" name="clientrecord" class="btn btn-elegant btn-sm " id="button">save record</button>  
<!--    <button  type="submit" name="clientrecord"  class="btn btn-elegant btn-sm " onclick="foo();" ><a >saved </a></button>-->
</form>
<?
include "submitclientorder.php";
?>
     </div>
    <hr class="hr-light">

     <div class="container-fluid row">
       <table class="table table-hover table-condensed table-striped" >
         <thead>
           <tr>
             <th>Milligarms</th>
             <th>Brand</th>
             <th>Price(shs)</th>
             <th>Stock</th>
             <th>Total(shs)</th>
             <th>Customer</th>
            <th>Date</th>

           </tr>
           </thead>
         <tbody id="dailyrecords">
           <? include 'retrieverecords.php';?>
         </tbody>
       </table>
     </div>

   </div>
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
   <script type="text/javascript">

     $(document).ready(function(){
     $("#select1").change(function(){
     var mls = $("#select1").val();
     $.post("brand.php",{value:mls},function(results){
       $("#brand").html(results);
       });
     });
   });
 $(document).ready(function(){
		$("#brand").change(function(){
			var mls = $("#brand").val();
			var milz=$("#select1").val();
			$.post("price.php",{brand:mls,qty:milz},function(resu){
				$("#price").html(resu);
				});
			});
		});
 $(document).ready(function(){
   $("#dailyrecords").load("retrieverecords.php",function(responseTxt,statusTxt,xhr){
     if(statusTxt =="success"){
       continue;
     }
     if(statusTxt !="success"){
       alert("ERROR:"+xhr.status());
     }
     });
   });
       $(document).ready(function(){
   		$("#brand").change(function(){
   			var mls = $("#brand").val();
   			var milz=$("#select1").val();
   			$.post("getstock.php",{brand:mls,qty:milz},function(resu){
   				$("#showStock").html(resu);
   				});
   			});
   		});
       
$(document).ready(function(){
  $("#order").keyup(function(){
    var qun1 = $("#order").val();
    var qun2 = $("#numavail").val();
    one = parseInt(qun1);
    two = parseInt(qun2);
    if(one > two){

      $("#order").addClass("border-danger");
        // alert("stock not enough");
        alert2();
        var button = $('#button');
    $(button).attr('disabled', 'disabled');

      }
      else{
         var button = $('#button');
        $(button).removeAttr('disabled');
      }
  });
});


 
   </script>


</section>

</div>
    <!--    the edit modal-->
    
    <!-- Frame Modal Bottom -->
<div class="modal fade bottom" id="frameModalBottom" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="false" >

    <!-- Add class .modal-frame and then add class .modal-bottom (or other classes from list above) to set a position to the modal -->
    <div class="modal-dialog  modal-frame modal-bottom" role="document">


      <div class="modal-content ">
        <div class="modal-body d-flex justify-content-center danger-color-dark">
          <div class="row">

              <div class=" container-fliud ml-5 pl-5 ">
		<form method="post" class="ml-5 pl-5" >
	<div class="form-row">
		<div class="form-group ">
			<div class="input-group input-group-sm">
			<select contenteditable="true" name="milligrams" id="select1" class="form-control form-control-sm">
				<option class="bg-dark" value="<? echo $qtyId;?>"><? echo $qty; ?></option>
				<?php include "quantity.inc.php"; ?>
			</select>
			</div>
		</div>
		<div class=" form-group ">
			<div class="input-group input-group-sm">
				<select name="brand" id="brand" class="form-control form-control-sm">
				<option class="bg-dark" value="<? echo $brandid;?>"><? echo $brandname; ?></option>
				<span id="brand"></span>
			</select>
			</div>	
			
		</div>
		<div class=" form-group ">
			
			<div class="input-group input-group-sm">
				<input type="number" min="0" value="<? echo $stock; ?>" class="form-control form-control-sm" name="deliveries" required id="deliveries">
			</div>
		</div>
		
		<div class="form-group">
			<button type="submit" class="btn btn-elegant btn-sm ml-2 mt-0" name="submit" data-dismiss="modal">CHANGE</button>
		</div>
        
	</div>
                      
</form>
        
	</div>

           
            
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Frame Modal Bottom -->
<!--/the edit modal-->

<?php include"footer.php"?>
