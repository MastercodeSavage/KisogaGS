-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 16, 2018 at 08:40 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dailystockkeep`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brandid` varchar(20) NOT NULL,
  `brandname` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brandid`, `brandname`) VALUES
('B1', 'COKE'),
('B10', 'SCH SODA WATER'),
('B11', 'COKE ZERO'),
('B12', 'FANTA ZERO'),
('B13', 'SPRITE ZERO'),
('B14', 'STONEY ZERO'),
('B15', 'SPARLETTA'),
('B16', 'VIMITO'),
('B17', 'MINUTE MAID MANGO'),
('B18', 'MINUTE MAID BERRY BLAST'),
('B19', 'MINUTE MAID ORANGE'),
('B2', 'FANTA ORANGE'),
('B20', 'MINUTE MAID'),
('B21', 'PLUS C'),
('B22', 'FUZE TEA PEACH'),
('B23', 'FUZE TEA APPLE LEMON GRASS'),
('B24', 'RWENZORI'),
('B25', 'DASANI'),
('B26', 'MONSTER ENERGY'),
('B27', 'M.KHAOS ENERGY'),
('B28', 'MONSTER ASSULT'),
('B29', 'POWER PLAY'),
('B3', 'FANTA...'),
('B30', 'POWER PLAY ZERO'),
('B4', 'FANTA FRUIT BLAST'),
('B5', 'SPRITE'),
('B6', 'KREST BITTER LEMON'),
('B7', 'STONEY TANGAWIZI'),
('B8', 'SCH NOVIDA PINEAPLE'),
('B9', 'SCH TONIC'),
('BR31', 'VIRGIN MOJITO');

-- --------------------------------------------------------

--
-- Table structure for table `ccbadelivery`
--

CREATE TABLE `ccbadelivery` (
  `count` int(10) NOT NULL,
  `bottle` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `ccbdelivery` int(20) NOT NULL,
  `total` int(20) NOT NULL,
  `empty` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ccbadelivery`
--

INSERT INTO `ccbadelivery` (`count`, `bottle`, `date`, `ccbdelivery`, `total`, `empty`) VALUES
(1, 'BPR3', '2018-08-14', 55, 1017500, NULL),
(2, 'BPR15', '2018-08-15', 222, 5128200, NULL),
(3, 'BPR11', '2018-08-15', 89, 2055900, NULL),
(4, 'BPR10', '2018-08-15', 89, 1646500, NULL),
(5, 'BPR16', '2018-08-15', 67, 1547700, NULL),
(6, 'BPR31', '2018-08-15', 78, 1170000, NULL),
(7, 'BPR11', '2018-08-15', 78, 1801800, NULL),
(8, 'BPR10', '2018-08-15', 908, 16798000, NULL),
(9, 'BPR53', '2018-08-15', 3, 30000, NULL),
(10, 'BPR11', '2018-08-15', 3, 69300, NULL),
(11, 'BPR11', '2018-08-15', 3, 69300, NULL),
(12, 'BPR11', '2018-08-15', 3, 69300, NULL),
(13, 'BPR50', '2018-08-15', 1, 25000, NULL),
(14, 'BPR2', '2018-08-16', 56, 1036000, NULL),
(15, 'BPR16', '2018-08-16', 0, 0, NULL),
(16, 'BPR11', '2018-08-16', 67, 1547700, NULL),
(17, 'BPR34', '2018-08-16', 908, 13620000, NULL),
(18, 'BPR34', '2018-08-16', 908, 13620000, NULL),
(19, 'BPR34', '2018-08-16', 908, 13620000, NULL),
(20, 'BPR34', '2018-08-16', 908, 13620000, NULL),
(21, 'BPR34', '2018-08-16', 908, 13620000, NULL),
(22, 'BPR34', '2018-08-16', 908, 13620000, NULL),
(23, 'BPR34', '2018-08-16', 908, 13620000, NULL),
(24, 'BPR34', '2018-08-16', 908, 13620000, NULL),
(25, 'BPR34', '2018-08-16', 33, 495000, NULL),
(26, 'BPR12', '2018-08-16', 23, 531300, NULL),
(27, 'BPR16', '2018-08-16', 556555, 2147483647, NULL),
(28, 'BPR16', '2018-08-16', -5, -115500, NULL),
(29, 'BPR16', '2018-08-16', 22, 508200, NULL),
(30, 'BPR13', '2018-08-16', 44, 1016400, NULL),
(31, 'BPR10', '2018-08-16', 908, 16798000, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dailyrecord`
--

CREATE TABLE `dailyrecord` (
  `count` int(10) NOT NULL,
  `date` date DEFAULT NULL,
  `bottle` varchar(20) NOT NULL,
  `clientorder` int(10) NOT NULL,
  `total` int(20) NOT NULL,
  `client` int(20) NOT NULL,
  `dept` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dailyrecord`
--

INSERT INTO `dailyrecord` (`count`, `date`, `bottle`, `clientorder`, `total`, `client`, `dept`) VALUES
(1, '2018-08-15', 'BPR6', 69, 1276500, 3, 0),
(2, '2018-08-15', 'BPR23', 45, 540000, 2, 0),
(3, '2018-08-15', 'BPR14', 677, 15638700, 1, 0),
(4, '2018-08-15', 'BPR13', 45, 1039500, 3, 0),
(5, '2018-08-15', 'BPR10', 675, 12487500, 2, 0),
(6, '2018-08-16', 'BPR11', 67, 1547700, 1, 0),
(7, '2018-08-16', 'BPR1', -99, -1831500, 1, 0),
(8, '2018-08-16', 'BPR1', -99, -1831500, 1, 0),
(10, '2018-08-16', 'BPR16', 34, 785400, 1, 0),
(11, '2018-08-16', 'BPR16', 34, 785400, 1, 0),
(12, '2018-08-16', 'BPR16', 34, 785400, 1, 0),
(13, '2018-08-16', 'BPR16', 34, 785400, 1, 0),
(14, '2018-08-16', 'BPR16', 34, 785400, 1, 0),
(15, '2018-08-16', 'BPR16', 34, 785400, 1, 0),
(16, '2018-08-16', 'BPR10', 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `emptyprice`
--

CREATE TABLE `emptyprice` (
  `id` varchar(20) NOT NULL,
  `pricevalue` int(10) DEFAULT NULL,
  `brandname` varchar(20) DEFAULT NULL,
  `quantities` varchar(20) NOT NULL,
  `shellprice` int(10) DEFAULT NULL,
  `shellplusbottle` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emptyprice`
--

INSERT INTO `emptyprice` (`id`, `pricevalue`, `brandname`, `quantities`, `shellprice`, `shellplusbottle`) VALUES
('EMP1', 400, NULL, 'QT1', 6400, 16000),
('EMP2', 400, NULL, 'QT2', 8100, 16000),
('EMP3', 700, NULL, 'QT3', 7400, 16000);

-- --------------------------------------------------------

--
-- Table structure for table `filledbottles`
--

CREATE TABLE `filledbottles` (
  `id` varchar(20) NOT NULL,
  `pricevalue` int(10) DEFAULT NULL,
  `brandid` varchar(20) NOT NULL,
  `quantites` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `filledbottles`
--

INSERT INTO `filledbottles` (`id`, `pricevalue`, `brandid`, `quantites`) VALUES
('BPR1', 18500, 'B1', 'QT1'),
('BPR10', 18500, 'B10', 'QT1'),
('BPR11', 23100, 'B1', 'QT2'),
('BPR12', 23100, 'B2', 'QT2'),
('BPR13', 23100, 'B4', 'QT2'),
('BPR14', 23100, 'B5', 'QT2'),
('BPR15', 23100, 'B1', 'QT3'),
('BPR16', 23100, 'B2', 'QT3'),
('BPR17', 23100, 'B5', 'QT3'),
('BPR18', 12000, 'B1', 'QT4'),
('BPR19', 12000, 'B2', 'QT4'),
('BPR2', 18500, 'B2', 'QT1'),
('BPR20', 12000, 'B5', 'QT4'),
('BPR21', 10000, 'B4', 'QT4'),
('BPR22', 12000, 'B6', 'QT4'),
('BPR23', 12000, 'B7', 'QT4'),
('BPR24', 12000, 'B8', 'QT4'),
('BPR25', 10000, 'B11', 'QT4'),
('BPR26', 10000, 'B12', 'QT4'),
('BPR27', 10000, 'B13', 'QT4'),
('BPR28', 10000, 'B14', 'QT4'),
('BPR29', 10000, 'B15', 'QT4'),
('BPR3', 18500, 'B3', 'QT1'),
('BPR30', 10000, 'B16', 'QT4'),
('BPR31', 15000, 'B1', 'QT5'),
('BPR32', 15000, 'B4', 'QT5'),
('BPR33', 15000, 'B5', 'QT5'),
('BPR34', 15000, 'B6', 'QT5'),
('BPR35', 15000, 'B7', 'QT5'),
('BPR36', 15000, 'B8', 'QT5'),
('BPR37', 15000, 'B11', 'QT5'),
('BPR38', 15000, 'B12', 'QT5'),
('BPR39', 15000, 'B13', 'QT5'),
('BPR4', 18500, 'B4', 'QT1'),
('BPR40', 15000, 'B14', 'QT5'),
('BPR41', 15000, 'B15', 'QT5'),
('BPR42', 15000, 'B16', 'QT5'),
('BPR43', 18500, 'B8', 'QT6'),
('BPR44', 20300, 'B1', 'QTL2'),
('BPR45', 20300, 'B2', 'QTL2'),
('BPR46', 20300, 'B5', 'QTL2'),
('BPR47', 20300, 'B16', 'QTL2'),
('BPR48', 20300, 'B4', 'QTL2'),
('BPR49', 20300, 'B11', 'QTL2'),
('BPR5', 18500, 'B5', 'QT1'),
('BPR50', 25000, 'BR31', 'QT7'),
('BPR52', 18000, 'B24', 'QT8'),
('BPR53', 10000, 'B1', 'QT9'),
('BPR54', 9600, 'B25', 'QT3'),
('BPR56', 9600, 'B25', 'QT4'),
('BPR57', 9600, 'B25', 'QT5'),
('BPR58', 20400, 'B17', 'QT7'),
('BPR59', 20400, 'B18', 'QT7'),
('BPR6', 18500, 'B6', 'QT1'),
('BPR60', 20400, 'B19', 'QT7'),
('BPR61', 20400, 'B20', 'QT7'),
('BPR62', 17500, 'B21', 'QT7'),
('BPR63', 20400, 'B22', 'QT7'),
('BPR64', 20400, 'B22', 'QT7'),
('BPR65', 20400, 'B18', 'QT3'),
('BPR66', 10500, 'B26', 'QT7'),
('BPR67', 10500, 'B27', 'QT7'),
('BPR68', 10500, 'B28', 'QT7'),
('BPR69', 17500, 'B29', 'QT7'),
('BPR7', 18500, 'B7', 'QT1'),
('BPR70', 17500, 'B30', 'QT7'),
('BPR8', 18500, 'B8', 'QT1'),
('BPR9', 18500, 'B9', 'QT1');

-- --------------------------------------------------------

--
-- Table structure for table `marketeer`
--

CREATE TABLE `marketeer` (
  `id` int(11) NOT NULL,
  `MarkName` varchar(80) NOT NULL,
  `contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marketeer`
--

INSERT INTO `marketeer` (`id`, `MarkName`, `contact`) VALUES
(1, 'Kizito Christopher', '0751182968'),
(2, 'Segawa Ronald', '0756130366'),
(3, 'Katunze Ronald', '0752002007');

-- --------------------------------------------------------

--
-- Table structure for table `quantites`
--

CREATE TABLE `quantites` (
  `quantityid` varchar(20) NOT NULL,
  `mills` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quantites`
--

INSERT INTO `quantites` (`quantityid`, `mills`) VALUES
('QT1', 300),
('QT2', 500),
('QT3', 1000),
('QT4', 350),
('QT5', 500),
('QT6', 1500),
('QT7', 400),
('QT8', 750),
('QT9', 230),
('QTL2', 2);

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `count` int(10) NOT NULL,
  `dateofentry` timestamp NULL DEFAULT NULL,
  `openingstock` int(10) DEFAULT NULL,
  `deliveredstock` int(10) DEFAULT NULL,
  `dailysales` int(10) DEFAULT NULL,
  `remainder` int(10) DEFAULT NULL,
  `filledbottles` varchar(20) NOT NULL,
  `loosebottles` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `recordempty`
--

CREATE TABLE `recordempty` (
  `count` int(20) NOT NULL,
  `date` date NOT NULL,
  `empty` varchar(20) NOT NULL,
  `bottleorder` int(10) DEFAULT NULL,
  `shellorder` int(10) DEFAULT NULL,
  `bottleplusshell` int(10) DEFAULT NULL,
  `bottletotal` int(20) DEFAULT NULL,
  `shelltotal` int(20) DEFAULT NULL,
  `bpstotal` int(20) DEFAULT NULL,
  `dept` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recordempty`
--

INSERT INTO `recordempty` (`count`, `date`, `empty`, `bottleorder`, `shellorder`, `bottleplusshell`, `bottletotal`, `shelltotal`, `bpstotal`, `dept`) VALUES
(1, '2018-08-15', 'EMP2', 56, 0, 0, 22400, 0, 0, 0),
(2, '2018-08-15', 'EMP1', 0, 67, 0, 0, 428800, 0, 0),
(3, '2018-08-15', 'EMP1', 0, 56, 0, 0, 358400, 0, 1),
(4, '2018-08-15', 'EMP1', 0, 0, 98, 0, 0, 1568000, 1),
(5, '2018-08-15', 'EMP1', 878, 0, 0, 351200, 0, 0, 1),
(8, '2018-08-15', 'EMP1', 44, 0, 0, 17600, 0, 0, 1),
(9, '2018-08-15', 'EMP3', 0, 0, 33, 0, 0, 528000, 1),
(10, '2018-08-16', 'EMP1', 0, 0, 33, 0, 0, 528000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `user_email`, `password`) VALUES
('Katunze J Moses', 'katunzejmoses07@gmail.com', 'katunze');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brandid`);

--
-- Indexes for table `ccbadelivery`
--
ALTER TABLE `ccbadelivery`
  ADD PRIMARY KEY (`count`),
  ADD KEY `FKfilledbott134` (`bottle`) USING BTREE,
  ADD KEY `empty` (`empty`);

--
-- Indexes for table `dailyrecord`
--
ALTER TABLE `dailyrecord`
  ADD PRIMARY KEY (`count`),
  ADD KEY `bottle` (`bottle`),
  ADD KEY `client` (`client`);

--
-- Indexes for table `emptyprice`
--
ALTER TABLE `emptyprice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKemptyPrice705076` (`quantities`),
  ADD KEY `FKemptyPrice847012` (`brandname`);

--
-- Indexes for table `filledbottles`
--
ALTER TABLE `filledbottles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKfilledbott134` (`quantites`),
  ADD KEY `FKfilledbott456675` (`brandid`);

--
-- Indexes for table `marketeer`
--
ALTER TABLE `marketeer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quantites`
--
ALTER TABLE `quantites`
  ADD PRIMARY KEY (`quantityid`);

--
-- Indexes for table `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`count`),
  ADD KEY `FKrecord593451` (`filledbottles`),
  ADD KEY `FKrecord301332` (`loosebottles`);

--
-- Indexes for table `recordempty`
--
ALTER TABLE `recordempty`
  ADD PRIMARY KEY (`count`),
  ADD KEY `empty` (`empty`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ccbadelivery`
--
ALTER TABLE `ccbadelivery`
  MODIFY `count` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `dailyrecord`
--
ALTER TABLE `dailyrecord`
  MODIFY `count` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `marketeer`
--
ALTER TABLE `marketeer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `record`
--
ALTER TABLE `record`
  MODIFY `count` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recordempty`
--
ALTER TABLE `recordempty`
  MODIFY `count` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ccbadelivery`
--
ALTER TABLE `ccbadelivery`
  ADD CONSTRAINT `ccbadelivery_ibfk_1` FOREIGN KEY (`bottle`) REFERENCES `filledbottles` (`id`),
  ADD CONSTRAINT `ccbadelivery_ibfk_2` FOREIGN KEY (`empty`) REFERENCES `emptyprice` (`id`);

--
-- Constraints for table `dailyrecord`
--
ALTER TABLE `dailyrecord`
  ADD CONSTRAINT `dailyrecord_ibfk_1` FOREIGN KEY (`bottle`) REFERENCES `filledbottles` (`id`),
  ADD CONSTRAINT `dailyrecord_ibfk_2` FOREIGN KEY (`client`) REFERENCES `marketeer` (`id`);

--
-- Constraints for table `emptyprice`
--
ALTER TABLE `emptyprice`
  ADD CONSTRAINT `FKemptyPrice705076` FOREIGN KEY (`quantities`) REFERENCES `quantites` (`quantityid`),
  ADD CONSTRAINT `FKemptyPrice847012` FOREIGN KEY (`brandname`) REFERENCES `brand` (`brandid`);

--
-- Constraints for table `filledbottles`
--
ALTER TABLE `filledbottles`
  ADD CONSTRAINT `FKfilledbott134` FOREIGN KEY (`quantites`) REFERENCES `quantites` (`quantityid`),
  ADD CONSTRAINT `FKfilledbott456675` FOREIGN KEY (`brandid`) REFERENCES `brand` (`brandid`);

--
-- Constraints for table `record`
--
ALTER TABLE `record`
  ADD CONSTRAINT `FKrecord301332` FOREIGN KEY (`loosebottles`) REFERENCES `emptyprice` (`id`),
  ADD CONSTRAINT `FKrecord593451` FOREIGN KEY (`filledbottles`) REFERENCES `filledbottles` (`id`);

--
-- Constraints for table `recordempty`
--
ALTER TABLE `recordempty`
  ADD CONSTRAINT `recordempty_ibfk_1` FOREIGN KEY (`empty`) REFERENCES `emptyprice` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
