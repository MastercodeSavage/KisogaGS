 <?php
$d = date("Y-m-d");
include "connection.inc.php";
$query = mysqli_query($conn,"SELECT * FROM recordempty WHERE bottleplusshell > '0' AND bpstotal > '0'  AND date='$d' ORDER BY count DESC" );
if($query){
	while($row = mysqli_fetch_array($query)){
		$count = $row['count'];
		$empty = $row['empty'];
        $sales_man=$row['sale_man_id'];
		$bottleorder = $row['bottleplusshell'];
		$bottletotal = $row['bpstotal'];
		$dep =$row['dept'];
        $dbc = mysqli_query($conn,"SELECT MarkName FROM marketeer WHERE id = '$sales_man'");
	$extract = mysqli_fetch_array($dbc);
	$Markname = $extract['MarkName'];
		$nquery = mysqli_query($conn,"SELECT quantities FROM emptyprice WHERE id= '$empty'");
		while($rw = mysqli_fetch_array($nquery)){
			$qty = $rw['quantities'];
			$s="SELECT mills FROM quantites WHERE quantityid = '$qty' ";
			$rs = mysqli_query($conn,$s);
			while($r=mysqli_fetch_array($rs)){
				$qtyv=$r['mills'];
			}
?>			
			<tr <? if($dep=="1"){ echo "class='bg-danger' ";} ?> >
				<td> <? echo $qtyv;?> </td>
				<td><? echo $bottleorder;?></td>
				<td><? echo $bottletotal;?></td>
                 <td><? echo $Markname;?></td>
			</tr>
<?			
		}
	}
}
?>