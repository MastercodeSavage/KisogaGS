<?php
include "connection.inc.php";
//price snipet
if(isset($_POST['brand'])){
$brand = $_POST['brand'];
$milz = $_POST['qty'];
$sql= "SELECT pricevalue FROM filledbottles WHERE brandid='$brand' AND quantites='$milz' ";
$query= mysqli_query($conn,$sql);
while($row = mysqli_fetch_array($query))
{
	$price = $row['pricevalue'];
}
?>
<!--<div class=""><label class="label label-danger"> unit price =</label></div>-->
<label class="badge badge-dark   text-center ">unit</label>
<input type="text"class=" form-control form-control-sm "  value="<? echo $price; ?>"  readonly="readonly" placeholder="price read only">

<?
     
}

?>