<?php
include "connection.inc.php";
if(isset($_POST['record'])){
	$quantity = $_POST['quantity'];
	$brand = $_POST['brand'];
	$delivery = $_POST['deliveries'];
	 //$q = mysqli_real_escape_string($quantity);

	$sql = "SELECT * FROM  filledbottles WHERE brandid='$brand' AND quantites = '$quantity'";
	$query = mysqli_query($conn,$sql);
	while($dt = mysqli_fetch_array($query)){
		$id = $dt['id'];
		$price = $dt['pricevalue'];
		$total = $price * $delivery;

	$d = date("Y-m-d");
	$sq = "INSERT INTO ccbadelivery (count, bottle, date, ccbdelivery, total, empty) VALUES (NULL, '$id', '$d', '$delivery', '$total', NULL)";
	$sz = "SELECT * FROM total_stock_table WHERE bottle='$id'";
	$q=mysqli_query($conn,$sz);
	while ($r = mysqli_fetch_array($q)) {
		$stock_amount = $r['stock_amount'];
		$stock_total = $r['stock_total'];
		$stock_amount = $stock_amount + $delivery;
		$stock_total = $stock_total + $total;

		$sx = mysqli_query($conn,"SELECT * FROM total_stock_table_daily WHERE date='$d' AND bottle='$id'");
		if(mysqli_num_rows($sx)>0){
			$dbq = mysqli_query($conn,"UPDATE total_stock_table_daily SET  amount='$stock_amount',total='$stock_total' WHERE bottle='$id' AND date='$d'");
		}
		else {
			$dbq = mysqli_query($conn,"INSERT INTO total_stock_table_daily (count,date,amount,total,bottle)VALUES('NULL','$d','$stock_amount','$stock_total','$id') ");
		}

		}

	$sqt = "UPDATE total_stock_table SET stock_amount='$stock_amount',stock_total='$stock_total' WHERE bottle='$id' ";
	$qu = mysqli_query($conn,$sqt);

	$query2 = mysqli_query($conn,$sq);
	if($query2 && $qu){

?>
	<script type="text/javascript">
		document.ccbaDelivery.resset();
		window.reload();
		document.ccbaDelivery.resset();
	</script>
<?php
	}else{
?>
	<script type="text/javascript">
		alert("failure");
	</script>
<?php
	}
 }
}
?>
