<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <!--<h3>KISOGA GENERAL STORES</h3>-->
            <img  class="img-responsive mx-auto" src="img/kgs.png" width="100%" height="100%">
        </div>

       <div class="container-fluid mt-0">
         <ul class="list-unstyled components">
            
            <li class="active">
                <a rel="item1" class="fa fa-dashboard " href="dash_home.php"> Dashboard</a>
              
            </li>
            <li >
                <a  rel="item2"href="client_order.php" class=" mt-2 fa fa-user active"> Client order</a>
                
            </li>
       
            <li>
                <a rel="item3"href="ccba.php" class=" mt-2 fa fa-truck"> Ccba delivery</a>
            </li>
            <li>
                <a  rel="item4"href="stat.php" class=" mt-2 fa fa-line-chart"> Sales performance</a>
                 
            </li>
            <li>
                <a href="history.php" class=" mt-2 fa fa-book"> Sales history</a>
                
            </li>
            
        </ul>
       </div>
     </nav>
     
