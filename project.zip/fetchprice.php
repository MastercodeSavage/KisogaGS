<?php
if(isset($_POST['value'])){
	$pas = $_POST['value'];
	echo $pas;
	include "connection.inc.php";
	$query = mysqli_query($conn,"SELECT * FROM emptyprice WHERE quantities ='$pas'");
	while($row = mysqli_fetch_array($query)){
		$pricevalue = $row['pricevalue'];
		$shellprice = $row['shellprice'];
		$bottleplusshell = $row['shellplusbottle'];
	
	
?>
<td><? echo $pricevalue; ?></td>
<td><? echo $shellprice; ?></td>
<td><? echo $bottleplusshell; ?></td>
<?	
	}
}
?>