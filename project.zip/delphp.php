<?php
if(isset($_POST['clear']))
{
	$val = $_POST['clear'];
	include "connection.inc.php";
	$sql = mysqli_query($conn,"UPDATE dailyrecord SET dept='0' WHERE count = '$val' ");
	if($sql){
?>
<script type="text/javascript">
	alert("Debt has succesfully been cleared");
</script>
<?		
		header('Location: client_order.php');
	}
}

?>